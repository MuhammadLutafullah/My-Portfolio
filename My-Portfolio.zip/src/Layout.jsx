const Layout = () => {
  return <></>;
};

export default Layout;
